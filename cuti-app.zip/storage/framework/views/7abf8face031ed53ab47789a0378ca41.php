
<?php $__env->startSection('content'); ?>
<div class="p-2">
    <div class="px-4 py-3 d-flex justify-content-between align-items-center">
        <div style="line-height: 15px;">
            <span class="fw-bold">List Alasan Pengajuan Cuti</span></br>
        </div>
        <div>
            <a href="<?php echo e(route('reason-create')); ?>" class="btn btn-dark text-warning py-1" style="font-size: 12px;">Tambah Alasan</a>
        </div>
    </div>
    <div class="py-1 px-4">
        <div class="card">
            <div class="card-body">
                <table class="table" style="font-size: 13px;">
                    <thead>
                        <tr>
                            <th style="width: 40px;">No</th>
                            <th>Jenis Pengajuan</th>
                            <th>Alasan</th>
                            <th class="text-center" style="width: 150px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($reason) == 0): ?>
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data alasan pengajuan</td>
                        </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $reason; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?>.</td>
                            <td><?php echo e($val->absense_jenis_model->jenis); ?></td>
                            <td><?php echo e($val->alasan); ?></td>
                            <td>
                                <div class="d-flex justify-content-center" style="gap: 5px">
                                    <a href="<?php echo e(route('reason-update', ['id' => $val->id])); ?>" class="btn border-warning fw-semibold py-1" style="font-size: 12px;">Ubah</a>
                                    <a href="<?php echo e(route('reason-delete', ['id' => $val->id])); ?>" class="btn border-danger fw-semibold py-1" style="font-size: 12px;">Hapus</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layouts_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\cuti-app\resources\views/pages/master/reason/index.blade.php ENDPATH**/ ?>