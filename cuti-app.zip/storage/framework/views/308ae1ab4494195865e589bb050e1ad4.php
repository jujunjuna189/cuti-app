
<?php $__env->startSection('content'); ?>
<div class="p-2">
    <div class="py-4 px-4 d-flex justify-content-center">
        <div class="card w-75">
            <div class="card-header bg-white d-flex justify-content-between">
                <span class="fw-bold text-dark">Ubah Jenis Pengajuan</span>
            </div>
            <div class="card-body" style="font-size: 13px;">
                <form action="<?php echo e(route('type-update-store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($type->id); ?>">
                    <div class="form-group mb-2">
                        <label for="jenis">Jenis</label>
                        <input type="text" name="jenis" id="jenis" value="<?php echo e($type->jenis); ?>" required placeholder="..." class="form-control">
                    </div>
                    <div class="form-group mt-4">
                        <button type="button" class="btn border-dark fw-semibold" style="font-size: 14px;" onclick="window.open('<?= url()->previous() ?>', '_self')">Kembali</button>
                        <button type="submit" class="btn btn-dark text-warning fw-semibold" style="font-size: 14px;">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layouts_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\cuti-app\resources\views/pages/master/type/form/update.blade.php ENDPATH**/ ?>