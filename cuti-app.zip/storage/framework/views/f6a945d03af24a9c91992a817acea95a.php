
<?php $__env->startSection('content'); ?>
<div class="p-2">
    <div class="px-4 py-3">
        <div style="line-height: 15px;">
            <span class="fw-bold">Data Pengajuan Cuti</span></br>
            <small style="font-size: 10px;">List data pengajuan cuti anda</small>
        </div>
    </div>
    <div class="py-1 px-4">
        <div class="card">
            <div class="card-body">
                <table class="table" style="font-size: 13px;">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Lengkap</th>
                            <th>Jenis</th>
                            <th>Alasan</th>
                            <th>Lama</th>
                            <th>Tanggal Dari</th>
                            <th>Tanggal Sampai</th>
                            <th>Atasan</th>
                            <th>Status</th>
                            <th class="text-center" style="width: 150px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($absense) == 0): ?>
                        <tr>
                            <td colspan="10" class="text-center">Tidak ada data pengajuan cuti</td>
                        </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $absense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($val->user->name); ?></td>
                            <td><?php echo e($val->jenis); ?></td>
                            <td><?php echo e($val->alasan); ?></td>
                            <td><?php echo e($val->lama); ?> Hari</td>
                            <td><?php echo e($val->tgl_dari); ?></td>
                            <td><?php echo e($val->tgl_sampai); ?></td>
                            <td><?php echo e($val->atasan->name ?? 'Atasan tidak ditemukan'); ?></td>
                            <td>
                                <div class="rounded text-center <?php echo e($controller->status_format($val->status)['text-color']); ?> <?php echo e($controller->status_format($val->status)['bg-color']); ?> bg-opacity-10 fw-semibold">
                                    <?php echo e($val->status); ?>

                                </div>
                            </td>
                            <td>
                                <div class="d-flex justify-content-center" style="gap: 5px">
                                    <a href="<?php echo e(route('absense-form-update-store', ['id' => $val->id, 'status' => 'Disetujui'])); ?>" class="btn border-success fw-semibold py-1" style="font-size: 12px;">Disetujui</a>
                                    <a href="<?php echo e(route('absense-form-update-store', ['id' => $val->id, 'status' => 'Ditolak'])); ?>" class="btn border-danger fw-semibold py-1" style="font-size: 12px;">Ditolak</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layouts_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\cuti-app\resources\views/pages/absense/indexAtasan.blade.php ENDPATH**/ ?>