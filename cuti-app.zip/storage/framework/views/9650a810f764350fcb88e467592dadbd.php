
<?php $__env->startSection('content'); ?>
<div class="p-2">
    <div class="py-4 px-4 d-flex justify-content-center">
        <div class="card w-75">
            <div class="card-header bg-white d-flex justify-content-between">
                <span class="fw-bold text-dark">Isi Pengajuan Cuti Anda</span>
                <div class="border border-dark px-2 rounded"><a href="<?php echo e(route('absense')); ?>" class="small text-dark text-decoration-none">Lihat pengajuan cuti</a></div>
            </div>
            <div class="card-body" style="font-size: 13px;">
                <form action="<?php echo e(route('absense-form-store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                    <div class="form-group mb-2">
                        <label for="jenis">Jenis cuti yang diambil</label>
                        <select name="jenis" id="jenis" class="form-control" onchange="onGetAlasan(this)">
                            <option value="" data-id="" disabled selected>--Pilih jenis cuti--</option>
                            <?php $__currentLoopData = $absensi_jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->jenis); ?>" data-id="<?php echo e($val->id); ?>"><?php echo e($val->jenis); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group mb-2">
                        <label for="jenis">Alasan cuti</label>
                        <select name="alasan" id="alasan" class="form-control" required>
                            <option value="" data-id="" disabled selected>--Pilih alasan cuti--</option>
                        </select>
                    </div>
                    <div class="form-group mb-2">
                        <label for="jenis">Lama Cuti</label>
                        <input type="text" name="lama" id="lama" placeholder="..." class="form-control">
                    </div>
                    <div class="form-group mb-2">
                        <label for="jenis">Tanggal Dari</label>
                        <input type="date" name="tgl_dari" id="tgl_dari" placeholder="..." class="form-control">
                    </div>
                    <div class="form-group mb-2">
                        <label for="jenis">Tanggal Sampai</label>
                        <input type="date" name="tgl_sampai" id="tgl_sampai" placeholder="..." class="form-control">
                    </div>
                    <div class="form-group mb-2">
                        <label for="atasan_id">Atasan</label>
                        <select name="atasan_id" id="atasan_id" class="form-control">
                            <option value="" disabled selected>--Pilih atasan--</option>
                            <?php $__currentLoopData = $atasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->id); ?>"><?php echo e($val->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group mt-4">
                        <button type="button" class="btn border-dark fw-semibold" style="font-size: 14px;">Kembali</button>
                        <button type="submit" class="btn btn-dark text-warning fw-semibold" style="font-size: 14px;">Ajukan Cuti</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const onGetAlasan = (data) => {
        var id = $(data).find(':selected').data('id');
        $.ajax({
            url: '<?= route("reason-get-by-jenis") ?>',
            type: "GET",
            dataType: 'json',
            data: {
                "absensi_jenis_id": id,
            },
            headers: {
                'X-CSRF-TOKEN': token,
            },
            success: function(data) {
                $('#alasan').empty();
                $('#alasan').append('<option value="" data-id="" disabled selected>--Pilih alasan cuti--</option>');
                data.forEach((item) => {
                    var html = '<option value="' + item.alasan + '">' + item.alasan + '</option>';
                    $('#alasan').append(html);
                });
            },
            error: function(error) {
                console.log(error);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layouts_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\cuti-app\resources\views/pages/absense/form/create.blade.php ENDPATH**/ ?>